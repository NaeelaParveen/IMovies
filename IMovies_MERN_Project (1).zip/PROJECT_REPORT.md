# IMovies — MERN Stack Movie Ticket Booking System
## Project Report (editable draft)

**Student Name:** __________________________  
**Enrollment/Roll Number:** __________________  
**Course / Branch:** _________________________  
**College:** _________________________________  
**Guide / Faculty:** __________________________  
**Academic Session:** _________________________  

---

## Certificate
This is to certify that the project titled **“IMovies — MERN Stack Movie Ticket Booking System”** has been prepared by the student named above as part of the academic project requirements. The work is submitted for evaluation under the guidance of the concerned faculty.

**Guide Signature:** _______________  **Date:** _______________  
**HOD Signature:** _________________  **Date:** _______________

## Acknowledgement
I would like to express my sincere gratitude to my project guide and faculty members for their guidance and support during the development of this project. I also thank my institution for providing the opportunity to apply web development concepts in a practical application. This project helped me understand frontend development, backend APIs, database integration, authentication, and software testing.

## Abstract
IMovies is a web-based movie ticket booking application developed using the MERN stack: MongoDB, Express.js, React.js, and Node.js. It provides an interface for browsing movies, reviewing basic movie information, selecting show dates and showtimes, choosing seats, and saving bookings for registered users. The backend exposes REST APIs for authentication, movie management, and booking operations. MongoDB stores user, movie, and booking records. The project demonstrates how a full-stack web application can connect a responsive user interface with server-side business logic and persistent storage.

## 1. Introduction
Booking cinema tickets manually can require customers to visit a counter or use separate services to check movie information and seat availability. IMovies demonstrates a single web interface for discovering movies and recording seat bookings. The project is intended as an academic prototype and can be extended with theatre selection, payment gateway integration, email notifications, and deployment.

## 2. Problem Statement
Users need a convenient way to browse movie listings and record ticket bookings. A simple, centralized application can organize movie details, showtimes, seat choices, and booking history. The system should also restrict booking history to the signed-in user and protect administrative movie-management endpoints.

## 3. Objectives
- Build a responsive movie discovery and booking interface.
- Implement user registration and login.
- Store movie and booking data in MongoDB.
- Provide REST APIs using Express.js and Node.js.
- Allow users to choose a date, showtime, and seats.
- Display a user's booking history.
- Protect movie-management endpoints using role-based authorization.
- Demonstrate the application through test cases and documentation.

## 4. Scope
The current version includes movie browsing/search, genre filters, user authentication, seat selection, booking records, and admin-only movie CRUD APIs. It does not process real payments or issue legally valid cinema tickets. Production deployment would require further validation, security review, transaction-safe seat reservation, and operational controls.

## 5. Technology Stack
- **MongoDB:** NoSQL database for users, movies, and bookings.
- **Express.js:** REST API framework.
- **React.js:** Component-based user interface.
- **Node.js:** JavaScript runtime for the backend.
- **Vite:** Frontend development server and build tool.
- **Mongoose:** MongoDB object modelling.
- **JWT:** Signed access tokens for API authentication.
- **bcryptjs:** Password hashing.
- **Git/GitHub:** Version control and source-code hosting.

## 6. System Requirements
### Hardware
- Laptop/desktop computer
- Minimum 4 GB RAM (8 GB recommended)
- Internet connection for package installation and remote poster images

### Software
- Windows, macOS, or Linux
- Node.js LTS and npm
- Visual Studio Code or another code editor
- MongoDB local server or MongoDB Atlas account
- Modern web browser
- Git (recommended)

## 7. System Architecture
The React frontend sends HTTP requests to the Express REST API. The API validates requests, checks authentication where required, applies booking or movie-management logic, and reads/writes data through Mongoose. MongoDB persists users, movies, and bookings.

**Flow:** User → React UI → Express API → Mongoose models → MongoDB  
**Authentication:** User credentials → bcrypt password hash verification → JWT token → protected API requests.

## 8. Main Modules
### 8.1 Movie Catalogue
Displays movie cards with title, genre, duration, language, rating, and price. Users can search by movie information and filter by genre.

### 8.2 Authentication
Registration stores a bcrypt-hashed password. Login checks the password and returns a JWT. Protected API routes use the token to identify the user.

### 8.3 Seat Selection
The interface displays seats in rows. Users select available seats and see the total price based on the movie's seat price. Previously booked seats can be retrieved from the API for a specific movie, date, and showtime.

### 8.4 Booking Management
A signed-in user can submit a booking. The backend validates required fields, checks that the movie and showtime exist, checks for conflicting seats, and stores the booking with a unique booking code.

### 8.5 Administration
Users whose database role is `admin` can create, update, and delete movie records through protected API endpoints. Admin status must be assigned securely by the database owner, not through public registration.

## 9. Database Design
### User
- `_id`: unique user identifier
- `name`: user's display name
- `email`: unique email address
- `passwordHash`: hashed password
- `role`: `user` or `admin`
- `createdAt`, `updatedAt`: timestamps

### Movie
- `_id`: unique movie identifier
- `title`: movie title
- `description`: summary
- `posterUrl`: poster image URL
- `genre`, `durationMinutes`, `rating`, `language`
- `showtimes`: list of available showtimes
- `price`: price per seat
- `createdAt`, `updatedAt`: timestamps

### Booking
- `_id`: unique booking identifier
- `user`: reference to User
- `movie`: reference to Movie
- `showtime`, `showDate`
- `seats`: selected seat identifiers
- `totalAmount`: price multiplied by number of seats
- `bookingCode`: unique booking reference
- `createdAt`, `updatedAt`: timestamps

## 10. API Endpoints
| Method | Endpoint | Purpose | Access |
|---|---|---|---|
| GET | `/api/health` | Check API status | Public |
| POST | `/api/auth/register` | Create account | Public |
| POST | `/api/auth/login` | Sign in | Public |
| GET | `/api/auth/me` | Current user | Authenticated |
| GET | `/api/movies` | List/search movies | Public |
| GET | `/api/movies/:id` | Get one movie | Public |
| POST | `/api/movies` | Add movie | Admin |
| PUT | `/api/movies/:id` | Update movie | Admin |
| DELETE | `/api/movies/:id` | Delete movie | Admin |
| GET | `/api/bookings/occupied` | Get booked seats | Public |
| POST | `/api/bookings` | Create booking | Authenticated |
| GET | `/api/bookings/mine` | View own bookings | Authenticated |

## 11. Implementation and Execution
Detailed installation and run commands are provided in `README.md`. The backend requires a valid MongoDB connection and `.env` configuration. The frontend can be started using Vite after installing dependencies. Demo movies are inserted by running the backend seed script.

## 12. Testing Plan
The following test cases should be executed and the **actual result** recorded after running the application.

| Test ID | Test | Expected Result | Actual Result |
|---|---|---|---|
| TC-01 | Open home page | Movie catalogue is displayed | __________ |
| TC-02 | Search for a movie title | Matching movies are displayed | __________ |
| TC-03 | Register with valid details | Account is created and user is signed in | __________ |
| TC-04 | Register with an existing email | Helpful error is shown | __________ |
| TC-05 | Login with incorrect password | Login is rejected | __________ |
| TC-06 | Select seats | Selected seats and total update | __________ |
| TC-07 | Book without logging in | User is asked to sign in | __________ |
| TC-08 | Submit valid booking | Booking is saved with a booking code | __________ |
| TC-09 | Open My Bookings | Signed-in user's bookings are shown | __________ |
| TC-10 | Call admin API as a regular user | Request is rejected | __________ |

## 13. Security Considerations
Passwords are stored as hashes rather than plain text. JWT authentication protects private endpoints, and role-based middleware restricts movie-management APIs. The `.env` file must not be committed to GitHub. For production, use a strong random JWT secret, request validation, rate limiting, secure deployment settings, transactional/atomic seat reservation, logging, and a security review. The current conflict check is suitable for a learning prototype but can be vulnerable to simultaneous booking races without a database transaction or unique seat-reservation model.

## 14. Limitations
- No real payment gateway.
- No email or SMS notifications.
- Sample movie data and external poster URLs are for demonstration.
- No theatre or screen management.
- Seat availability conflict handling needs stronger concurrency controls for production.
- Application has not been deployed by this project package; it must be configured and tested in the target environment.

## 15. Future Enhancements
- Integrate a payment gateway in test/sandbox mode.
- Add theatre locations and multiple screens.
- Use atomic seat reservation and booking expiry.
- Add email booking confirmations.
- Add movie reviews and favourites.
- Add admin dashboard UI and analytics.
- Deploy frontend and backend with environment-based configuration.
- Add automated unit and integration tests.

## 16. Conclusion
IMovies demonstrates a full-stack web application using the MERN stack. It combines a React interface with REST APIs and MongoDB persistence for users, movies, and bookings. The project provides practical experience with component-based UI development, API integration, authentication, data modelling, and basic role-based access control. Further testing and enhancements can improve its reliability and prepare it for production use.

## References
- React documentation: https://react.dev/
- Node.js documentation: https://nodejs.org/docs/
- Express documentation: https://expressjs.com/
- MongoDB documentation: https://www.mongodb.com/docs/
- Vite documentation: https://vite.dev/
- GitHub documentation: https://docs.github.com/
