# IMovies — MERN Movie Ticket Booking System

A student capstone project built with React (Vite), Node.js, Express, and MongoDB.

## Features
- Browse and search movies
- Movie detail and showtime selection
- Register and log in (JWT authentication)
- Select seats and create bookings
- View a user's booking history
- Admin API for adding, editing, and deleting movies
- Responsive dark cinema-themed interface
- Demo movie seed script

> This is a project starter intended for learning and academic demonstration. Before public deployment, add production-grade validation, rate limiting, email verification, payment integration, monitoring, and stronger authorization/security review.

## Requirements
- Node.js LTS
- npm
- MongoDB local instance or MongoDB Atlas connection string
- Git (optional, for GitHub)

## 1. Configure backend
Open a terminal in `backend/` and run:

```bash
npm install
```

Copy `.env.example` to `.env` and set:
- `MONGO_URI` to your MongoDB connection string
- `JWT_SECRET` to a long random secret
- `PORT=5000`
- `CLIENT_URL=http://localhost:5173`

Seed demo movies:

```bash
npm run seed
```

Start the backend:

```bash
npm run dev
```

API runs at `http://localhost:5000`.

## 2. Configure frontend
In a second terminal:

```bash
cd frontend
npm install
```

Create `frontend/.env` with:

```env
VITE_API_URL=http://localhost:5000/api
```

Start it:

```bash
npm run dev
```

Open the URL Vite prints (usually `http://localhost:5173`).

## Demo flow
1. Register an account from the website.
2. Log in.
3. Open a movie, choose a showtime and seats, then confirm the booking.
4. Open **My Bookings** to see bookings for the signed-in account.

## Admin
To create an admin, register normally, then update that user's `role` to `"admin"` in MongoDB. This is intentionally not exposed as a public UI action. Sign in again to use the admin controls/API.

Admin endpoints:
- `POST /api/movies` — add movie
- `PUT /api/movies/:id` — update movie
- `DELETE /api/movies/:id` — delete movie

All require a valid JWT for a user with role `admin`.

## GitHub
Create an empty repository named `IMovies`, then from the project root:

```bash
git init
git add .
git commit -m "Initial IMovies MERN project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/IMovies.git
git push -u origin main
```

Do not upload `.env` files or real secrets.

## Common issues
- `MongoServerSelectionError`: MongoDB isn't running or `MONGO_URI` is incorrect.
- `401 Unauthorized`: log out and log in again; token may be missing/expired.
- Port in use: change `PORT` in backend `.env` and update `VITE_API_URL`.
