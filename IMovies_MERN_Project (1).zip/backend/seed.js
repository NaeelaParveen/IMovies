import mongoose from "mongoose";
import dotenv from "dotenv";
import Movie from "./src/models/Movie.js";
dotenv.config();
const movies = [
  { title: "The Last Galaxy", description: "A young pilot discovers a signal that could change the fate of the galaxy.", posterUrl: "https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9OE8PY05Nxl1X.jpg", genre: "Sci-Fi", durationMinutes: 136, rating: "U/A", language: "English", showtimes: ["11:00 AM", "2:30 PM", "6:00 PM", "9:30 PM"], price: 220 },
  { title: "City of Dreams", description: "Two strangers chase their dreams in a city that never sleeps.", posterUrl: "https://image.tmdb.org/t/p/w500/6KErczPBROQty7QoIsaa6wJYXZi.jpg", genre: "Drama", durationMinutes: 124, rating: "U/A", language: "Hindi", showtimes: ["10:30 AM", "1:45 PM", "5:15 PM", "8:45 PM"], price: 180 },
  { title: "Shadow Protocol", description: "An intelligence analyst races to stop a cyberattack before midnight.", posterUrl: "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg", genre: "Thriller", durationMinutes: 118, rating: "UA 16+", language: "Hindi", showtimes: ["12:00 PM", "3:15 PM", "6:45 PM", "10:00 PM"], price: 200 },
  { title: "Summer Letters", description: "A heartfelt story about friendship, family, and second chances.", posterUrl: "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg", genre: "Romance", durationMinutes: 112, rating: "U", language: "Hindi", showtimes: ["11:30 AM", "2:00 PM", "5:30 PM", "8:00 PM"], price: 160 },
  { title: "Wild Horizon", description: "A rescue team ventures into the mountains after a storm cuts off a village.", posterUrl: "https://image.tmdb.org/t/p/w500/4q2hz2m8hubgvijz8Ez0T2Os2Yv.jpg", genre: "Adventure", durationMinutes: 129, rating: "U/A", language: "English", showtimes: ["10:00 AM", "1:30 PM", "5:00 PM", "8:30 PM"], price: 210 },
  { title: "Laugh Track", description: "A chaotic family reunion turns into a comedy of errors.", posterUrl: "https://image.tmdb.org/t/p/w500/8cdWjvZQUExUUTzyp4t6EDMubfO.jpg", genre: "Comedy", durationMinutes: 105, rating: "U", language: "Hindi", showtimes: ["12:15 PM", "3:00 PM", "6:15 PM", "9:00 PM"], price: 150 }
];
try {
  await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/imovies");
  await Movie.deleteMany({});
  await Movie.insertMany(movies);
  console.log(`Seeded ${movies.length} demo movies.`);
} catch (e) {
  console.error(e.message);
  process.exitCode = 1;
} finally { await mongoose.disconnect(); }
