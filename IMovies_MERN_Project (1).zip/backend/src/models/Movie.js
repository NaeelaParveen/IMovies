import mongoose from "mongoose";
const movieSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  posterUrl: { type: String, default: "" },
  genre: { type: String, default: "Drama" },
  durationMinutes: { type: Number, default: 120 },
  rating: { type: String, default: "U/A" },
  language: { type: String, default: "Hindi" },
  showtimes: { type: [String], default: ["12:30 PM", "4:00 PM", "7:30 PM"] },
  price: { type: Number, default: 180 }
}, { timestamps: true });
export default mongoose.model("Movie", movieSchema);
