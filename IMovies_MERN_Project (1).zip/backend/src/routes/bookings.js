import { Router } from "express";
import crypto from "crypto";
import Booking from "../models/Booking.js";
import Movie from "../models/Movie.js";
import { protect } from "../middleware/auth.js";

const router = Router();
router.get("/mine", protect, async (req, res, next) => {
  try {
    const bookings = await Booking.find({ user: req.user._id }).populate("movie").sort({ createdAt: -1 });
    res.json(bookings);
  } catch (e) { next(e); }
});
router.get("/occupied", async (req, res, next) => {
  try {
    const { movieId, showDate, showtime } = req.query;
    if (!movieId || !showDate || !showtime) return res.status(400).json({ message: "movieId, showDate, and showtime are required." });
    const bookings = await Booking.find({ movie: movieId, showDate, showtime }).select("seats");
    res.json([...new Set(bookings.flatMap(b => b.seats))]);
  } catch (e) { next(e); }
});
router.post("/", protect, async (req, res, next) => {
  try {
    const { movieId, showtime, showDate, seats } = req.body;
    if (!movieId || !showtime || !showDate || !Array.isArray(seats) || seats.length < 1 || seats.length > 10)
      return res.status(400).json({ message: "Choose a movie, date, showtime, and between 1 and 10 seats." });
    if (new Set(seats).size !== seats.length || seats.some(s => !/^[A-F]-(?:[1-8])$/.test(s)))
      return res.status(400).json({ message: "One or more seat selections are invalid." });
    const movie = await Movie.findById(movieId);
    if (!movie) return res.status(404).json({ message: "Movie not found." });
    if (!movie.showtimes.includes(showtime)) return res.status(400).json({ message: "Invalid showtime." });
    const conflict = await Booking.findOne({ movie: movieId, showDate, showtime, seats: { $in: seats } });
    if (conflict) return res.status(409).json({ message: "One or more seats have just been booked. Refresh seat selection." });
    const booking = await Booking.create({
      user: req.user._id, movie: movie._id, showtime, showDate, seats,
      totalAmount: movie.price * seats.length,
      bookingCode: "IM-" + crypto.randomBytes(4).toString("hex").toUpperCase()
    });
    res.status(201).json(await booking.populate("movie"));
  } catch (e) { next(e); }
});
export default router;
