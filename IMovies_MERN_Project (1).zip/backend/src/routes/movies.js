import { Router } from "express";
import Movie from "../models/Movie.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();
router.get("/", async (req, res, next) => {
  try {
    const filter = req.query.search ? { title: { $regex: req.query.search, $options: "i" } } : {};
    res.json(await Movie.find(filter).sort({ createdAt: -1 }));
  } catch (e) { next(e); }
});
router.get("/:id", async (req, res, next) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (!movie) return res.status(404).json({ message: "Movie not found." });
    res.json(movie);
  } catch (e) { next(e); }
});
router.post("/", protect, adminOnly, async (req, res, next) => {
  try { res.status(201).json(await Movie.create(req.body)); } catch (e) { next(e); }
});
router.put("/:id", protect, adminOnly, async (req, res, next) => {
  try {
    const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!movie) return res.status(404).json({ message: "Movie not found." });
    res.json(movie);
  } catch (e) { next(e); }
});
router.delete("/:id", protect, adminOnly, async (req, res, next) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (!movie) return res.status(404).json({ message: "Movie not found." });
    res.json({ message: "Movie deleted." });
  } catch (e) { next(e); }
});
export default router;
