import { useEffect, useMemo, useState } from "react";
import { Clapperboard, Search, Ticket, UserRound, LogOut, X, CalendarDays, Clock3, MapPin, Film, Sparkles, ChevronRight, CheckCircle2, Armchair, Menu } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const fallbackMovies = [
  { _id:"demo1", title:"The Last Galaxy", description:"A young pilot discovers a signal that could change the fate of the galaxy.", posterUrl:"https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9OE8PY05Nxl1X.jpg", genre:"Sci-Fi", durationMinutes:136, rating:"U/A", language:"English", showtimes:["11:00 AM","2:30 PM","6:00 PM","9:30 PM"], price:220 },
  { _id:"demo2", title:"City of Dreams", description:"Two strangers chase their dreams in a city that never sleeps.", posterUrl:"https://image.tmdb.org/t/p/w500/6KErczPBROQty7QoIsaa6wJYXZi.jpg", genre:"Drama", durationMinutes:124, rating:"U/A", language:"Hindi", showtimes:["10:30 AM","1:45 PM","5:15 PM","8:45 PM"], price:180 },
  { _id:"demo3", title:"Shadow Protocol", description:"An intelligence analyst races to stop a cyberattack before midnight.", posterUrl:"https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg", genre:"Thriller", durationMinutes:118, rating:"UA 16+", language:"Hindi", showtimes:["12:00 PM","3:15 PM","6:45 PM","10:00 PM"], price:200 },
  { _id:"demo4", title:"Summer Letters", description:"A heartfelt story about friendship, family, and second chances.", posterUrl:"https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg", genre:"Romance", durationMinutes:112, rating:"U", language:"Hindi", showtimes:["11:30 AM","2:00 PM","5:30 PM","8:00 PM"], price:160 },
  { _id:"demo5", title:"Wild Horizon", description:"A rescue team ventures into the mountains after a storm cuts off a village.", posterUrl:"https://image.tmdb.org/t/p/w500/4q2hz2m8hubgvijz8Ez0T2Os2Yv.jpg", genre:"Adventure", durationMinutes:129, rating:"U/A", language:"English", showtimes:["10:00 AM","1:30 PM","5:00 PM","8:30 PM"], price:210 },
  { _id:"demo6", title:"Laugh Track", description:"A chaotic family reunion turns into a comedy of errors.", posterUrl:"https://image.tmdb.org/t/p/w500/8cdWjvZQUExUUTzyp4t6EDMubfO.jpg", genre:"Comedy", durationMinutes:105, rating:"U", language:"Hindi", showtimes:["12:15 PM","3:00 PM","6:15 PM","9:00 PM"], price:150 }
];
const money = n => new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n || 0);
const today = () => new Date().toISOString().slice(0,10);

export default function App() {
  const [movies,setMovies] = useState([]);
  const [query,setQuery] = useState("");
  const [activeGenre,setActiveGenre] = useState("All");
  const [selected,setSelected] = useState(null);
  const [modal,setModal] = useState("");
  const [user,setUser] = useState(() => JSON.parse(localStorage.getItem("imoviesUser") || "null"));
  const [token,setToken] = useState(() => localStorage.getItem("imoviesToken") || "");
  const [authMode,setAuthMode] = useState("login");
  const [authForm,setAuthForm] = useState({name:"",email:"",password:""});
  const [formError,setFormError] = useState("");
  const [showDate,setShowDate] = useState(today());
  const [showtime,setShowtime] = useState("");
  const [seats,setSeats] = useState([]);
  const [occupied,setOccupied] = useState([]);
  const [bookings,setBookings] = useState([]);
  const [notice,setNotice] = useState("");
  const [busy,setBusy] = useState(false);
  const [mobileNav,setMobileNav] = useState(false);

  async function request(path, options={}) {
    const res = await fetch(`${API}${path}`, { ...options, headers: { "Content-Type":"application/json", ...(token ? {Authorization:`Bearer ${token}`} : {}), ...(options.headers||{}) }});
    const data = await res.json().catch(()=>({}));
    if (!res.ok) throw new Error(data.message || "Something went wrong.");
    return data;
  }
  async function loadMovies() {
    try { const data = await request(`/movies${query ? `?search=${encodeURIComponent(query)}` : ""}`); setMovies(data); }
    catch { setMovies(fallbackMovies); }
  }
  useEffect(()=>{ loadMovies(); },[query]);
  useEffect(()=>{ if (token) { request("/auth/me").then(d=>{setUser(d.user);localStorage.setItem("imoviesUser",JSON.stringify(d.user));}).catch(()=>logout(false)); } },[]);
  const genres = useMemo(()=>["All",...new Set(movies.map(m=>m.genre).filter(Boolean))],[movies]);
  const filtered = movies.filter(m => (activeGenre==="All" || m.genre===activeGenre) && `${m.title} ${m.genre} ${m.language}`.toLowerCase().includes(query.toLowerCase()));
  function logout(show=true) { setToken("");setUser(null);localStorage.removeItem("imoviesToken");localStorage.removeItem("imoviesUser");if(show) setNotice("You've been logged out."); }
  function openMovie(movie) { setSelected(movie);setShowtime(movie.showtimes?.[0] || "7:30 PM");setShowDate(today());setSeats([]);setOccupied([]);setModal("movie"); }
  async function refreshOccupied(movie=selected,time=showtime,date=showDate) {
    if (!movie || movie._id.startsWith("demo")) { setOccupied([]);return; }
    try { const data=await request(`/bookings/occupied?movieId=${movie._id}&showDate=${date}&showtime=${encodeURIComponent(time)}`);setOccupied(data); } catch { setOccupied([]); }
  }
  useEffect(()=>{ if(modal==="movie") refreshOccupied(); },[showtime,showDate,selected?._id,modal]);
  async function submitAuth(e) {
    e.preventDefault();setFormError("");setBusy(true);
    try {
      const data=await request(`/auth/${authMode}`,{method:"POST",body:JSON.stringify(authForm)});
      setToken(data.token);setUser(data.user);localStorage.setItem("imoviesToken",data.token);localStorage.setItem("imoviesUser",JSON.stringify(data.user));
      setModal("");setNotice(`Welcome${data.user.name ? `, ${data.user.name}` : ""}!`);
    } catch(e){setFormError(e.message);} finally{setBusy(false);}
  }
  function toggleSeat(seat) { if(occupied.includes(seat)) return;setSeats(old=>old.includes(seat)?old.filter(s=>s!==seat):old.length>=10?old:[...old,seat]); }
  async function confirmBooking() {
    if (!user) { setAuthMode("login");setModal("auth");setNotice("Log in to complete your booking.");return; }
    if (!seats.length) return;
    if (selected._id.startsWith("demo")) { setNotice("Connect MongoDB and seed movies to save real bookings. Demo browsing is available now.");return; }
    setBusy(true);
    try {
      const booking=await request("/bookings",{method:"POST",body:JSON.stringify({movieId:selected._id,showtime,showDate,seats})});
      setModal("success");setBookings(old=>[booking,...old]);setNotice("");
    } catch(e){setFormError(e.message);await refreshOccupied();} finally{setBusy(false);}
  }
  async function openBookings() {
    if(!user){setAuthMode("login");setModal("auth");return;}
    try{setBookings(await request("/bookings/mine"));setModal("bookings");}
    catch(e){setNotice(e.message);}
  }
  const dateLabel = new Date(`${showDate}T12:00:00`).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={e=>{e.preventDefault();setModal("");window.scrollTo({top:0,behavior:"smooth"});}}><span className="brand-icon"><Clapperboard size={22}/></span><span>i<span className="brand-red">MOVIES</span><small>YOUR CINEMA, YOUR WAY</small></span></a>
      <nav className={mobileNav?"nav nav-open":"nav"}><a href="#movies" onClick={()=>setMobileNav(false)}>Movies</a><a href="#experience" onClick={()=>setMobileNav(false)}>Experience</a><button className="nav-link" onClick={openBookings}><Ticket size={16}/> My Bookings</button></nav>
      <div className="header-actions">{user?<><span className="user-chip"><UserRound size={16}/>{user.name.split(" ")[0]}</span><button className="icon-btn" title="Log out" onClick={()=>logout()}><LogOut size={17}/></button></>:<button className="btn btn-outline btn-small" onClick={()=>{setAuthMode("login");setFormError("");setModal("auth");}}>Sign in <ChevronRight size={15}/></button>}<button className="menu-btn" onClick={()=>setMobileNav(!mobileNav)}><Menu/></button></div>
    </header>
    {notice && <div className="notice" role="status">{notice}<button onClick={()=>setNotice("")}><X size={15}/></button></div>}
    <main>
      <section className="hero">
        <div className="hero-shade"></div><div className="hero-content">
          <div className="eyebrow"><Sparkles size={15}/> THE BIG SCREEN FEELS BETTER</div>
          <h1>Stories worth<br/> <span>stepping into.</span></h1>
          <p>Find your next favourite. Pick your seats. Make it a movie night.</p>
          <a className="btn btn-primary" href="#movies">Explore movies <ChevronRight size={18}/></a>
          <div className="hero-stats"><div><strong>01</strong><span>Pick a film</span></div><i></i><div><strong>02</strong><span>Choose seats</span></div><i></i><div><strong>03</strong><span>Enjoy the show</span></div></div>
        </div>
        <div className="hero-badge"><span>NOW SHOWING</span><strong>YOUR NEXT<br/>FAVOURITE FILM</strong><Clapperboard size={25}/></div>
      </section>
      <section className="content-section" id="movies">
        <div className="section-heading"><div><div className="eyebrow red-eyebrow">CURATED FOR YOU</div><h2>Now <span>showing</span></h2><p>Big stories. Unforgettable moments.</p></div><label className="search-box"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search movies..." aria-label="Search movies"/></label></div>
        <div className="genre-row">{genres.map(g=><button key={g} className={activeGenre===g?"genre active":"genre"} onClick={()=>setActiveGenre(g)}>{g}</button>)}</div>
        {filtered.length ? <div className="movie-grid">{filtered.map((m,i)=><article className="movie-card" key={m._id}><button className="poster-button" onClick={()=>openMovie(m)} aria-label={`View ${m.title}`}><img className="poster" src={m.posterUrl} alt={`${m.title} poster`} onError={e=>{e.currentTarget.style.display="none";e.currentTarget.nextSibling.style.display="grid";}}/><div className="poster-fallback" style={{display:"none"}}><Film size={42}/><span>{m.title}</span></div><span className="poster-rating">{m.rating||"U/A"}</span><span className="poster-cta">View details <ChevronRight size={16}/></span></button><div className="movie-info"><div className="movie-meta"><span>{m.genre}</span><span>•</span><span>{m.durationMinutes} min</span></div><h3>{m.title}</h3><div className="movie-bottom"><span className="price">{money(m.price)} <small>/ seat</small></span><button className="round-arrow" onClick={()=>openMovie(m)} aria-label={`Book ${m.title}`}><ChevronRight size={18}/></button></div></div></article>)}</div>:<div className="empty-state"><Film size={34}/><h3>No movies found</h3><p>Try another title or genre.</p></div>}
      </section>
      <section className="experience" id="experience"><div className="experience-icon"><Armchair size={30}/></div><div><div className="eyebrow">YOUR NIGHT, UPGRADED</div><h2>The best seat in the house<br/><span>is the one you choose.</span></h2><p>Pick your people, choose your seats, and let the opening scene do the rest.</p></div><a href="#movies" className="btn btn-outline">Find a movie <ChevronRight size={17}/></a></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-icon"><Clapperboard size={20}/></span><span>i<span className="brand-red">MOVIES</span><small>YOUR CINEMA, YOUR WAY</small></span></a><p>Made for movie lovers. <span>© {new Date().getFullYear()} IMovies</span></p><span className="footer-tag">LIGHTS. CAMERA. YOU.</span></footer>

    {modal==="auth"&&<div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setModal("")}><section className="modal auth-modal"><button className="close-btn" onClick={()=>setModal("")}><X/></button><div className="modal-mark"><Clapperboard/></div><div className="eyebrow red-eyebrow">WELCOME TO IMOVIES</div><h2>{authMode==="login"?"Good to see you.":"Join the audience."}</h2><p className="modal-sub">{authMode==="login"?"Sign in to manage your movie nights.":"Create an account to book your seats."}</p><form onSubmit={submitAuth}>{authMode==="register"&&<label>Full name<input required value={authForm.name} onChange={e=>setAuthForm({...authForm,name:e.target.value})} placeholder="Your name"/></label>}<label>Email address<input required type="email" value={authForm.email} onChange={e=>setAuthForm({...authForm,email:e.target.value})} placeholder="you@example.com"/></label><label>Password<input required minLength="8" type="password" value={authForm.password} onChange={e=>setAuthForm({...authForm,password:e.target.value})} placeholder="At least 8 characters"/></label>{formError&&<div className="form-error">{formError}</div>}<button disabled={busy} className="btn btn-primary full-btn">{busy?"Please wait…":authMode==="login"?"Sign in":"Create account"} <ChevronRight size={17}/></button></form><p className="switch-auth">{authMode==="login"?"New to IMovies?":"Already have an account?"} <button onClick={()=>{setAuthMode(authMode==="login"?"register":"login");setFormError("");}}> {authMode==="login"?"Create an account":"Sign in"}</button></p></section></div>}
    {modal==="movie"&&selected&&<div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setModal("")}><section className="modal booking-modal"><button className="close-btn" onClick={()=>setModal("")}><X/></button><div className="booking-top"><div className="booking-poster">{selected.posterUrl?<img src={selected.posterUrl} alt="" onError={e=>e.currentTarget.style.display="none"}/>:<Film/>}</div><div><div className="eyebrow red-eyebrow">NOW BOOKING</div><h2>{selected.title}</h2><p>{selected.description}</p><div className="detail-tags"><span>{selected.genre}</span><span>{selected.durationMinutes} min</span><span>{selected.language}</span><span>{selected.rating}</span></div></div></div><div className="booking-options"><label><CalendarDays size={17}/> Show date<input type="date" min={today()} value={showDate} onChange={e=>{setShowDate(e.target.value);setSeats([]);}}/></label><label><Clock3 size={17}/> Show time<select value={showtime} onChange={e=>{setShowtime(e.target.value);setSeats([]);}}>{(selected.showtimes||["7:30 PM"]).map(t=><option key={t}>{t}</option>)}</select></label></div><div className="seat-heading"><div><h3>Choose your seats</h3><p>Select up to 10 seats</p></div><span className="seat-price">{money(selected.price)} <small>/ seat</small></span></div><div className="screen-wrap"><div className="screen"></div><span>SCREEN THIS WAY</span></div><div className="seat-map">{["A","B","C","D","E","F"].map(row=><div className="seat-row" key={row}><b>{row}</b>{[1,2,3,4,5,6,7,8].map(n=>{const s=`${row}-${n}`,off=occupied.includes(s);return <button key={s} disabled={off} className={`seat ${off?"occupied":seats.includes(s)?"chosen":""}`} title={off?"Already booked":s} onClick={()=>toggleSeat(s)}>{n}</button>})}<b>{row}</b></div>)}</div><div className="seat-legend"><span><i className="legend-free"></i> Available</span><span><i className="legend-selected"></i> Selected</span><span><i className="legend-taken"></i> Booked</span></div>{formError&&<div className="form-error">{formError}</div>}<div className="booking-total"><div><span>{seats.length} seat{seats.length===1?"":"s"} selected</span><strong>{money(seats.length*selected.price)}</strong></div><button disabled={!seats.length||busy} className="btn btn-primary" onClick={confirmBooking}>{busy?"Booking…":"Confirm booking"} <ChevronRight size={17}/></button></div></section></div>}
    {modal==="success"&&<div className="overlay"><section className="modal success-modal"><div className="success-icon"><CheckCircle2 size={42}/></div><div className="eyebrow red-eyebrow">BOOKING CONFIRMED</div><h2>It's movie time!</h2><p>Your seats are reserved. Keep your booking details handy at the cinema.</p>{bookings[0]&&<div className="ticket-card"><div><span>BOOKING CODE</span><strong>{bookings[0].bookingCode}</strong></div><div><span>MOVIE</span><strong>{bookings[0].movie?.title||selected?.title}</strong></div><div><span>DATE & SHOW</span><strong>{bookings[0].showDate} · {bookings[0].showtime}</strong></div><div><span>SEATS</span><strong>{bookings[0].seats?.join(", ")}</strong></div><div><span>TOTAL</span><strong>{money(bookings[0].totalAmount)}</strong></div></div>}<button className="btn btn-primary full-btn" onClick={()=>setModal("")}>Back to movies</button></section></div>}
    {modal==="bookings"&&<div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setModal("")}><section className="modal history-modal"><button className="close-btn" onClick={()=>setModal("")}><X/></button><div className="eyebrow red-eyebrow">YOUR CINEMA HISTORY</div><h2>My bookings</h2><p className="modal-sub">All your movie plans, in one place.</p>{bookings.length?<div className="history-list">{bookings.map(b=><article className="history-item" key={b._id}><div className="history-icon"><Ticket/></div><div className="history-details"><h3>{b.movie?.title||"Movie"}</h3><p><CalendarDays size={14}/> {b.showDate} <Clock3 size={14}/> {b.showtime}</p><p>Seats: {b.seats.join(", ")} · {b.bookingCode}</p></div><strong>{money(b.totalAmount)}</strong></article>)}</div>:<div className="empty-state"><Ticket size={34}/><h3>No bookings yet</h3><p>Your next movie night starts here.</p></div>}<button className="btn btn-outline full-btn" onClick={()=>setModal("")}>Close</button></section></div>}
  </div>;
}
